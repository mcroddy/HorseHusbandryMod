package com.example.examplemod;

public class ClientProxy {
}

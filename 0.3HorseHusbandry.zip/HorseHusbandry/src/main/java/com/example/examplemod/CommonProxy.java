package com.example.examplemod;

public class CommonProxy {
}

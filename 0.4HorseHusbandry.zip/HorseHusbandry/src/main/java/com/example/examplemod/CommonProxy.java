package com.example.examplemod;

import net.minecraft.item.Item;

public class CommonProxy {
    public void registerItemRenderer(Item item, int meta, String id)
    {

    }
}
